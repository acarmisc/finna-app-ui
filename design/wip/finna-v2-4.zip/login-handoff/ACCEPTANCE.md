# Login · Acceptance checklist

Run through this before merging. Each box should be tickable from the running build, not from the Figma.

## Visual fidelity

- [ ] Two-column layout: brand rail (50%) + sign-in card (50%) at ≥900px width.
- [ ] Below 900px: brand rail hidden, card centered.
- [ ] Brand rail shows the dithered grid + radial primary glow background.
- [ ] Brand mark renders as `> finna` with green caret, Press Start 2P, ~22px.
- [ ] Headline renders in Press Start 2P with the `in one console.` accent in primary color.
- [ ] Three KPI tiles ($1.2M / 3 / 99.9%) below the headline, JetBrains Mono numbers.
- [ ] Card "Sign in to Finna" title is regular (Inter), 22px.
- [ ] 4 SSO buttons + SAML SSO row, all the same height, equal vertical gap.
- [ ] Each SSO button: provider icon, name (left), `OAuth`/`SAML`/`Enterprise` mono meta tag (right).
- [ ] `or` divider between SSO and email link.
- [ ] Dashed-border `Sign in with email and password` toggle visible by default.
- [ ] Clicking toggle reveals: email input, password row with `Forgot?` link, primary `[ SIGN IN ]` button, back-to-SSO link.
- [ ] Footer: `Need an account? Contact admin` left, `v2.4.1` mono right.

## Theme parity

- [ ] Loads with the system theme (or `localStorage` value if set) without FOUC.
- [ ] Setting `<html data-theme="light">` flips all colors atomically.
- [ ] Light theme: WCAG AA contrast on all text and badge labels.
- [ ] Dark theme: scanline overlay does not interfere with focus rings.

## Interactions

- [ ] Clicking an SSO button shows `Redirecting…` on that row, disables all buttons, then redirects to the IdP.
- [ ] Clicking SAML SSO behaves the same.
- [ ] Email/password submit with empty fields shows inline error (`Enter a password to continue.`).
- [ ] Bad credentials show inline error from server (`Email or password is incorrect.`).
- [ ] MFA-required, rate-limited, network-error all show their copy (test with mocked errors).
- [ ] Submit button label changes to `[ AUTHENTICATING… ]` while pending.
- [ ] Pressing Enter in the email or password field submits the form.
- [ ] Back-to-SSO link returns to the SSO list (form state is preserved if you re-open).

## Accessibility

- [ ] Tab order: brand mark skipped (aside is `aria-hidden="true"`), then SSO buttons in order, then divider skip, then email toggle / form fields, then footer link.
- [ ] All buttons reachable by keyboard with visible focus ring (2px primary outline).
- [ ] `<form>` is wrapped in a `<main>`; brand rail is `<aside>`.
- [ ] Inline error has `role="alert"` so screen readers announce on appearance.
- [ ] Email input has `autoComplete="username"`, password has `autoComplete="current-password"`.
- [ ] All decorative SVGs are `aria-hidden` (icons inside buttons inherit accessible name from the button label).
- [ ] Color contrast: meta tag (`OAuth`, `SAML`, etc.) ≥ 4.5:1 against surface.

## Responsive

- [ ] At 360px: card padding doesn't clip, all text readable.
- [ ] At 1440px: brand rail KPI grid stays 3-up.
- [ ] Press Start 2P scales linearly without subpixel rounding artifacts.

## Performance

- [ ] LCP ≤ 1.5s on cable + cached fonts.
- [ ] No layout shift when fonts swap (Press Start 2P fallback metrics close enough).
- [ ] Total JS for `/login` route ≤ 80KB gzipped (excluding shared chunks).

## Functional

- [ ] Successful SSO redirects to `/auth/callback`, which exchanges code and lands on `/dashboard`.
- [ ] Successful email login navigates to `/dashboard` (or wherever your app default is).
- [ ] Hitting `/login` while already authenticated redirects to `/dashboard`.
- [ ] Hitting any protected route while logged out redirects to `/login?next=…`.
- [ ] After login, deep-link `next` is honored.

## Cross-browser

- [ ] Chrome 124+, Edge 124+, Safari 17+, Firefox 124+ all render identically.
- [ ] Mobile Safari iOS 17+ — keyboard appears with correct input types.
- [ ] No console errors or warnings on any of the above.
