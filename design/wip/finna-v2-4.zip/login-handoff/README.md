# Finna v2 · Login — Engineering Handoff

This package gives you everything needed to ship the Finna v2 login screen without referring back to the rest of the mockup.

```
login-handoff/
├── README.md                  ← this file
├── IMPLEMENTATION.md          ← step-by-step port guide
├── BACKEND-CONTRACT.md        ← what the auth backend must expose
├── ACCEPTANCE.md              ← QA checklist before ship
├── assets/
│   ├── tokens.css             ← design tokens (dark + light)
│   ├── login.css              ← all login-only styles
│   ├── LoginPage.tsx          ← production-ready React component
│   └── preview/
│       ├── login.html         ← open this to see the design rendered
│       ├── login-preview.css  ← preview-only support styles
│       └── fonts.html         ← font import snippet
└── design/
    └── login-dark.png         ← reference screenshot (open the preview HTML for the light theme — `?theme=light`)
```

## Quick start

1. Open `assets/preview/login.html` in a browser to see the target design.
2. Read `IMPLEMENTATION.md` for the 6-step port to your codebase.
3. Read `BACKEND-CONTRACT.md` and align with the auth team.
4. Use `ACCEPTANCE.md` as the gate before merging.

## What's in scope

- Two-column login: branded left rail, sign-in card on the right.
- 4 SSO providers (Google, Microsoft, Okta, GitHub) + SAML enterprise + email/password fallback.
- Pixel-art corporate aesthetic (sharp corners, Press Start 2P titles, JetBrains Mono buttons, chunky pixel-step shadows).
- Dark + light theme parity (driven by `[data-theme]` on `<html>`).
- Responsive: brand rail collapses below 900px, card centers.
- Accessibility: semantic landmarks, focus rings, keyboard navigation, ARIA labels.

## What's NOT in scope (and where it lives)

| Concern | Where |
|---|---|
| Token exchange / refresh / `/auth/me` | full handoff pack — `03-auth.md` |
| Protected routes / route guards | full handoff pack — `01-architecture.md` |
| Theme toggle UX (top bar) | full handoff pack — `04-app-shell.md` |
| `Forgot password` flow | future ticket |
| Magic-link / passkey | future ticket |

## Browser support

Latest 2 versions of Chrome, Edge, Safari, Firefox. No IE11. Mobile Safari and Chrome supported on devices ≥360px wide.
