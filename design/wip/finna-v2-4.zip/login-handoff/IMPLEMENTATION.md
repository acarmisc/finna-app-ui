# Login · Implementation guide

End-to-end, in 6 steps. Total time: ~2-3 hours.

## 0 · Prereqs

Your project should already have:

- React 18 + TypeScript
- React Router 6 (`BrowserRouter`)
- An axios (or fetch) client with `Authorization: Bearer …` header support
- A `useAuth()` hook or auth context that exposes `signIn`, `signOut`, `user`
- A way to register routes

If you don't have these yet, set them up before continuing.

## 1 · Drop in the assets

Copy the four files in `assets/` into your project:

| Source | Destination |
|---|---|
| `assets/tokens.css` | `src/styles/tokens.css` |
| `assets/login.css` | `src/features/auth/login.css` |
| `assets/LoginPage.tsx` | `src/features/auth/LoginPage.tsx` |

Add a fonts link to your `index.html` `<head>`:

```html
<link rel="preconnect" href="https://fonts.googleapis.com" />
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
<link
  rel="stylesheet"
  href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600;700&family=Press+Start+2P&display=swap"
/>
```

In your global stylesheet, import tokens before app styles:

```css
/* src/styles/index.css */
@import './tokens.css';
@import 'tailwindcss';   /* if using Tailwind */
/* …rest of your app styles… */
```

## 2 · Wire the auth service

`LoginPage` takes an `auth: AuthService` prop. Implement it once and reuse everywhere.

```ts
// src/features/auth/authService.ts
import axios from 'axios';
import { AuthError, type AuthService } from './LoginPage';

export const authService: AuthService = {
  async signInWithSso(providerId) {
    // Redirects out — this never resolves on success.
    const res = await axios.get(`/api/v1/auth/sso/${providerId}/start`);
    window.location.assign(res.data.authorize_url);
    // Tell TypeScript this branch never returns.
    return new Promise(() => {});
  },

  async signInWithPassword(email, password) {
    try {
      const { data } = await axios.post('/api/v1/auth/login', { email, password });
      saveTokens(data); // your storage layer
    } catch (e: any) {
      const code =
        e?.response?.status === 401 ? 'invalid_credentials' :
        e?.response?.status === 403 ? 'mfa_required' :
        e?.response?.status === 429 ? 'rate_limited' :
        !e?.response                ? 'network_error' :
        'unknown';
      throw new AuthError(code);
    }
  },
};
```

The expected backend contract is in `BACKEND-CONTRACT.md`.

## 3 · Mount the route

```tsx
// src/App.tsx
import { LoginPage } from './features/auth/LoginPage';
import { authService } from './features/auth/authService';
import './features/auth/login.css';

<Routes>
  <Route path="/login" element={
    <LoginPage auth={authService} version={import.meta.env.VITE_APP_VERSION} />
  } />
  <Route path="/auth/callback" element={<AuthCallback />} />
  {/* rest of your routes */}
</Routes>
```

`AuthCallback` is the OAuth redirect target — it reads `?code=…&state=…` from the URL, swaps it for tokens via `POST /api/v1/auth/sso/exchange`, and navigates to `/dashboard`. Trivial; not included here.

## 4 · Connect to your routing

When email/password sign-in succeeds, `LoginPage` returns control to you. Navigate after `await auth.signInWithPassword(…)`:

```ts
// Option A: pass an onSuccess prop (small change to LoginPage)
<LoginPage auth={authService} onSuccess={() => navigate('/dashboard')} />

// Option B (recommended): make signInWithPassword set the user
// in your auth context, and have a top-level <ProtectedRoute>
// redirect to /dashboard when auth becomes truthy.
```

Option B keeps `LoginPage` ignorant of routing — preferred.

## 5 · Theme support

Both light and dark are driven by `[data-theme]` on `<html>`. Set it on app boot:

```ts
// src/main.tsx
const stored = localStorage.getItem('finna_theme');
const theme = stored ?? (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
document.documentElement.setAttribute('data-theme', theme);
```

The login page has no in-page toggle on purpose — theme is set globally and the login screen inherits.

## 6 · Verify

Walk through `ACCEPTANCE.md`. Common issues:

- **Press Start 2P doesn't render** → fonts link missing from `index.html`. Hard refresh.
- **Buttons look square but no shadow** → `tokens.css` not imported, or imported after Tailwind reset.
- **`brackets-l` / `brackets-r` not styled** → those rules live in your main button styles. The minimum you need:
  ```css
  .btn .brackets-l, .btn .brackets-r { color: currentColor; opacity: 0.7; }
  .btn-primary { background: var(--primary); color: var(--primary-fg); border: 1px solid var(--primary); padding: 8px 12px; font-family: 'JetBrains Mono', monospace; text-transform: uppercase; box-shadow: var(--pxshadow-2); }
  .btn-block { width: 100%; display: inline-flex; justify-content: center; gap: 6px; }
  .inp { background: var(--surface); border: 1px solid var(--border); color: var(--fg); padding: 9px 11px; font-family: 'Inter', sans-serif; font-size: 13px; width: 100%; }
  .inp.error { border-color: var(--danger); }
  .field .label { font-size: 11px; font-weight: 600; color: var(--fg-muted); text-transform: uppercase; letter-spacing: 0.04em; margin-bottom: 6px; }
  .hint.error { font-size: 12px; color: var(--danger); }
  ```
  These are also bundled at the top of `login.css`.

## File-level notes

### `LoginPage.tsx`

- Takes `AuthService` via prop — avoid a singleton import so tests can inject mocks.
- `AuthError` is a typed exception class with codes; copy is in `ERROR_COPY` map.
- All copy is hard-coded. If you need i18n, replace strings with your `t()` calls.
- The component is fully controlled — no internal redirects. Navigation is your responsibility (see step 4).

### `login.css`

- Uses CSS custom properties only — never references your Tailwind utilities.
- Includes button + input rules so you can drop it on a project that doesn't have them yet.
- If your project already styles `.btn` / `.inp` / `.field`, prune those sections to avoid conflicts.

### `tokens.css`

- Single source of truth for color, surface, type. Don't duplicate values.
- Light theme uses `[data-theme="light"]` selector — make sure your boot script sets `[data-theme]` synchronously to avoid FOUC.
