# Login · Backend contract

What the auth backend must expose for the login screen to work end-to-end.

All routes are relative to `${VITE_API_URL}/api/v1` and use JSON. CSRF is not required when bearer tokens are stored in `localStorage`/`sessionStorage` and sent via `Authorization` header.

## SSO start

```
GET /auth/sso/{provider}/start

Path params:
  provider  google | microsoft | okta | github | saml

200 OK
{
  "authorize_url": "https://accounts.google.com/o/oauth2/v2/auth?...",
  "state": "opaque-csrf-token"
}
```

Frontend redirects the browser to `authorize_url`. Backend should set `state` in a short-lived signed cookie or session and verify it on callback.

## SSO callback exchange

```
POST /auth/sso/exchange
Content-Type: application/json

{
  "provider": "google",
  "code": "<from query string>",
  "state": "<from query string>"
}

200 OK
{
  "access_token": "<jwt>",
  "refresh_token": "<opaque>",
  "expires_in": 900,                  // seconds
  "token_type": "Bearer",
  "user": { "id": "u_…", "email": "…", "name": "…", "role": "admin|member|viewer" }
}
```

Errors:

| Status | `error.code` | When |
|---|---|---|
| 400 | `invalid_state` | state mismatch / CSRF |
| 400 | `invalid_code` | exchange with IdP failed |
| 403 | `domain_not_allowed` | user email outside allow-list |
| 502 | `idp_unreachable` | upstream IdP error |

## Email + password

```
POST /auth/login
Content-Type: application/json

{ "email": "you@company.com", "password": "…" }

200 OK
{ "access_token": "…", "refresh_token": "…", "expires_in": 900, "token_type": "Bearer", "user": {…} }
```

Errors:

| Status | `error.code` | UI copy |
|---|---|---|
| 401 | `invalid_credentials` | "Email or password is incorrect." |
| 403 | `mfa_required` | "Multi-factor required — check your authenticator app." |
| 429 | `rate_limited` | "Too many attempts. Try again in a minute." |
| 5xx | `unknown` | "Something went wrong. Try again." |

The `LoginPage` component maps these via `AuthError` — see `assets/LoginPage.tsx`.

## Rate limiting

- Email/password: 5 attempts per IP per 60s, lockout 5min after 10 attempts in 10min.
- SSO: 20 starts per IP per 60s.

Return `429` with `Retry-After` header when rate limited.

## Errors envelope (RFC 7807 — Problem+JSON)

All non-2xx responses use:

```json
{
  "type":   "about:blank",
  "title":  "Invalid credentials",
  "status": 401,
  "code":   "invalid_credentials",
  "detail": "Optional human-readable detail."
}
```

The frontend reads `code` first, then `title`, then maps to `ERROR_COPY`.

## CORS

```
Access-Control-Allow-Origin: <exact-app-origin>
Access-Control-Allow-Credentials: true
Access-Control-Allow-Headers: Authorization, Content-Type, Idempotency-Key
Access-Control-Allow-Methods: GET, POST, OPTIONS
```

## Security

- `access_token`: short-lived JWT (15 min), RS256, audience = `finna-console`.
- `refresh_token`: opaque, server-side revocable, 30-day rotating.
- Tokens are returned in JSON (not cookies) so the frontend can inject them via `Authorization` header.
- All endpoints require HTTPS in production. HSTS preload is enabled.
- Login form responses never leak whether an email exists — same 401 for unknown user and bad password.
